package com.example.puddles;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Poca fina que se espalha devagar (age 0..3) e depois evapora. */
public class PuddleBlock extends Block {
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 3);
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 1, 16);

    public PuddleBlock(Properties props) {
        super(props.randomTicks());
        registerDefaultState(stateDefinition.any().setValue(AGE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(AGE); }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return SHAPE; }

    @Override
    protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return Shapes.empty(); }

    @Override
    protected boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        return l.getBlockState(p.below()).isFaceSturdy(l, p.below(), Direction.UP);
    }

    @Override
    protected void randomTick(BlockState s, ServerLevel level, BlockPos pos, RandomSource r) {
        int age = s.getValue(AGE);
        if (age >= 3) { if (r.nextInt(4) == 0) level.removeBlock(pos, false); return; }
        Direction d = Direction.Plane.HORIZONTAL.getRandomDirection(r);
        BlockPos n = pos.relative(d);
        BlockState ns = defaultBlockState().setValue(AGE, age + 1);
        if (level.getBlockState(n).isAir() && ns.canSurvive(level, n) && r.nextInt(2) == 0) {
            level.setBlock(n, ns, 3);
            if (r.nextInt(3) == 0) level.setBlock(pos, s.setValue(AGE, age + 1), 3);
        }
    }
}
