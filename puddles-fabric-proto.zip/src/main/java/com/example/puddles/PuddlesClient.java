package com.example.puddles;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

// Camada TRANSLUCENT padrao do vanilla: sem shader proprio, entao funciona no Zink/GL4ES/MobileGlues.
public class PuddlesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(Puddles.PUDDLE, ChunkSectionLayer.TRANSLUCENT);
    }
}
