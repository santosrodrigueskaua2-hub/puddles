package com.example.puddles;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier; // se nao compilar: ResourceLocation
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public class Puddles implements ModInitializer {
    public static Block PUDDLE;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.fromNamespaceAndPath("puddles", "puddle");
        ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK, id);
        PUDDLE = Registry.register(BuiltInRegistries.BLOCK, id,
                new PuddleBlock(Block.Properties.of().setId(bk).noCollission().noOcclusion().instabreak().replaceable()));
        ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, id);
        Registry.register(BuiltInRegistries.ITEM, id,
                new BlockItem(PUDDLE, new Item.Properties().setId(ik).useBlockDescriptionPrefix()));
    }
}
